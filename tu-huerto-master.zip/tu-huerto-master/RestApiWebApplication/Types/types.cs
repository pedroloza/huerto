namespace RestApiWebApplication.Types
{
  public enum Status
  {
    Deleted,
    Inactive,
    Active,
  }

  public enum Gender
  {
    Male = 'M',
    Female = 'F',
  }
}