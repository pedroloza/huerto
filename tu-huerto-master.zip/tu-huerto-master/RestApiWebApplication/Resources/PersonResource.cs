namespace RestApiWebApplication.Resources
{
    public sealed record PersonResource(
        int Id,
        string Name,
        string LastName,
        string IdentificationCard,
        string BirthDate,
        string Gender
    );
}
