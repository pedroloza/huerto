namespace RestApiWebApplication.Resources
{
    public sealed record LoginDTO(string Email, string Password);
}
