using RestApiWebApplication.Types;

namespace RestApiWebApplication.Resources
{
    public sealed record UserResource(
        int Id,
        string Email,
        string Name,
        string LastName,
        Status Status
    );
}
