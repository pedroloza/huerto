namespace RestApiWebApplication.Resources
{
  public sealed record RegisterUserDTO(
    string Email,
    string IdentificationCard,
    string Name,
    string LastName,
    string Password,
    string BirthDate,
    string Address,
    string Gender
    );
}
