using Microsoft.EntityFrameworkCore;
using RestApiWebApplication.Models;
using RestApiWebApplication.Services;
using RestApiWebApplication.Types;

namespace RestApiWebApplication.DB
{
    public class Context : DbContext
    {
        private readonly string _pepper;
        private readonly int _iteration = 3;

        public Context(DbContextOptions<Context> context)
            : base(context)
        {
            _pepper = "pepper";
        }

        public DbSet<Person> People { get; set; }
        public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //
            // Relationships
            //
            modelBuilder
                .Entity<User>()
                .HasOne(u => u.Person)
                .WithOne(p => p.User)
                .HasForeignKey<User>(u => u.PersonId)
                .IsRequired();

            modelBuilder.Entity<User>().HasIndex(u => u.Email).IsUnique();

            //
            // Seed data
            //
            var adminEmail = "admin@demo.com";
            var adminPassword = "master";
            var adminSalt = PasswordHasher.GenerateSalt();
            var adminHash = PasswordHasher.ComputeHash(
                adminPassword,
                adminSalt,
                _pepper,
                _iteration
            );
            var adminName = "Admin";
            var adminLastName = "Demo";

            modelBuilder
                .Entity<Person>()
                .HasData(
                    new Person
                    {
                        Id = 1,
                        Name = adminName,
                        LastName = adminLastName,
                    }
                );

            modelBuilder
                .Entity<User>()
                .HasData(
                    new User
                    {
                        Id = 1,
                        Email = adminEmail,
                        PasswordSalt = adminSalt,
                        PasswordHash = adminHash,
                        Status = Status.Active,
                        PersonId = 1
                    }
                );
        }
    }
}
