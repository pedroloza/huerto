using System.ComponentModel.DataAnnotations;
using RestApiWebApplication.Resources;

namespace RestApiWebApplication.Models
{
    public class Person : BaseModel
    {
        [Required]
        public string Name { get; set; } = null!;

        [Required]
        public string LastName { get; set; } = null!;

        public string? IdentificationCard { get; set; } = null;

        public DateTime? BirthDate { get; set; } = null;

        public string? Address { get; set; } = null;

        public string? Gender { get; set; } = null;

        public User? User { get; set; }

        public Person() { }

        public PersonResource ToResource()
        {
            return new PersonResource(
                Id: Id,
                Name: Name,
                LastName: LastName,
                IdentificationCard: IdentificationCard ?? "",
                BirthDate: BirthDate?.ToString("yyyy-MM-dd") ?? "",
                Gender: Gender ?? ""
            );
        }
    }
}
