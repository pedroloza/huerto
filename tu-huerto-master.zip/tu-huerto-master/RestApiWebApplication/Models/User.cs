using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using RestApiWebApplication.Resources;
using RestApiWebApplication.Types;

namespace RestApiWebApplication.Models
{
    public class User : BaseModel
    {
        [Required]
        [MinLength(8)]
        [DataType(DataType.EmailAddress)]
        [RegularExpression(@"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$")]
        public required string Email { get; set; }

        public required string PasswordSalt { get; set; }

        public required string PasswordHash { get; set; }

        [Required]
        [DataType(DataType.Text)]
        [EnumDataType(typeof(Status))]
        [DisplayFormat(NullDisplayText = "Active")]
        [RegularExpression(@"^(Active|Inactive|Deleted)$")]
        [DefaultValue(Status.Active)]
        public Status Status { get; set; } = Status.Active;

        [Required]
        [ForeignKey("Person")]
        public int PersonId { get; set; }

        public Person Person { get; set; } = null!;

        public User() { }

        public UserResource ToResource()
        {
            return new UserResource(
                Id: Id,
                Email: Email,
                Name: Person.Name,
                LastName: Person.LastName,
                Status: Status
            );
        }
    }
}
