using RestApiWebApplication.DB;
using RestApiWebApplication.Models;
using RestApiWebApplication.Resources;

namespace RestApiWebApplication.Services
{
    public sealed class PeopleService : Service
    {
        public PeopleService(Context context) : base(context) { }

        public IEnumerable<PersonResource> GetPeople()
        {
            return _context.People.ToList().Select(p => p.ToResource());
        }

        public async Task<PersonResource?> GetPerson(int id)
        {
            var person = await _context.People.FindAsync(id);

            if (person is null)
            {
                return null;
            }

            return person.ToResource();
        }

        public async Task<PersonResource?> UpdatePerson(int id, Person person)
        {
            var personToUpdate = await _context.People.FindAsync(id);

            if (personToUpdate is null)
            {
                return null;
            }

            _context.People.Update(personToUpdate);
            await _context.SaveChangesAsync();

            return personToUpdate.ToResource();
        }

        public async Task<bool?> DeletePerson(int id)
        {
            var person = await _context.People.FindAsync(id);

            if (person is null)
            {
                return null;
            }

            _context.People.Remove(person);
            await _context.SaveChangesAsync();

            return true;
        }
    }
}
