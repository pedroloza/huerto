using RestApiWebApplication.DB;

namespace RestApiWebApplication.Services
{
    public class Service
    {
        public readonly Context _context;

        public Service(Context context)
        {
            _context = context;
        }
    }
}
