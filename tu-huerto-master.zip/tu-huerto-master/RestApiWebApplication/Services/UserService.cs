using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using RestApiWebApplication.DB;
using RestApiWebApplication.Models;
using RestApiWebApplication.Resources;

namespace RestApiWebApplication.Services
{
    public sealed class UserService : Service
    {
        private readonly string _pepper;
        private readonly int _iteration = 3;

        private readonly IConfiguration _configuration;

        public UserService(Context context, IConfiguration configuration)
            : base(context)
        {
            _pepper = "pepper";
            _configuration = configuration;
        }

        public async Task<UserResource> Register(
            RegisterUserDTO resource,
            CancellationToken cancellationToken
        )
        {
            var person = new Person
            {
                Name = resource.Name,
                LastName = resource.LastName,
                IdentificationCard = resource.IdentificationCard,
                BirthDate = DateTime.Parse(resource.BirthDate),
                Address = resource.Address,
                Gender = resource.Gender,
            };
            await _context.People.AddAsync(person, cancellationToken);
            await _context.SaveChangesAsync(cancellationToken);

            var user = new User
            {
                Email = resource.Email,
                PasswordSalt = PasswordHasher.GenerateSalt(),
                PasswordHash = "",
                PersonId = person.Id,
            };

            user.PasswordHash = PasswordHasher.ComputeHash(
                resource.Password,
                user.PasswordSalt,
                _pepper,
                _iteration
            );
            await _context.Users.AddAsync(user, cancellationToken);
            await _context.SaveChangesAsync(cancellationToken);

            return user.ToResource();
        }

        public async Task<string> Login(LoginDTO resource, CancellationToken cancellationToken)
        {
            var user = await _context
                .Users.Include(u => u.Person)
                .FirstOrDefaultAsync(x => x.Email == resource.Email, cancellationToken);

            if (user == null)
            {
                throw new Exception("Username or password did not match.");
            }

            var passwordHash = PasswordHasher.ComputeHash(
                resource.Password,
                user.PasswordSalt,
                _pepper,
                _iteration
            );

            if (user.PasswordHash != passwordHash)
            {
                throw new Exception("Username or password did not match.");
            }

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.Email),
                new Claim(ClaimTypes.Role, "Admin"),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim("UserId", user.Id.ToString()),
                new Claim("Name", user.Person.Name),
                new Claim("Status", user.Status.ToString()),
            };

            return GenerateToken(claims);
        }

        public IEnumerable<UserResource> GetUsers()
        {
            return _context.Users.Include(u => u.Person).ToList().Select(u => u.ToResource());
        }

        public async Task<UserResource?> GetUser(int id)
        {
            var user = await _context.Users.FindAsync(id);

            if (user is null)
            {
                return null;
            }

            return user.ToResource();
        }

        public async Task<UserResource?> UpdateUser(int id, User user)
        {
            var userToUpdate = await _context.Users.FindAsync(id);

            if (userToUpdate is null)
            {
                return null;
            }

            _context.Users.Update(userToUpdate);
            await _context.SaveChangesAsync();

            return userToUpdate.ToResource();
        }

        public async Task<bool?> DeleteUser(int id)
        {
            var user = await _context.Users.FindAsync(id);

            if (user is null)
            {
                return null;
            }

            _context.Users.Remove(user);
            await _context.SaveChangesAsync();

            return true;
        }

        private string GenerateToken(IEnumerable<Claim> claims)
        {
            var authSignInKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(
                    _configuration["JWT:Secret"] ?? "abcdefghijklmnopqrstuvwxyz123456"
                )
            );

            var tokenExpiryTimeInHours = Convert.ToInt64(
                _configuration["JWT:TokenExpiryTimeInHour"] ?? "1"
            );

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.UtcNow.AddHours(tokenExpiryTimeInHours),
                SigningCredentials = new SigningCredentials(
                    authSignInKey,
                    SecurityAlgorithms.HmacSha256
                ),
                Issuer = _configuration["JWT:ValidIssuer"],
                Audience = _configuration["JWT:ValidAudience"],
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);

            return tokenHandler.WriteToken(token);
        }
    }
}
