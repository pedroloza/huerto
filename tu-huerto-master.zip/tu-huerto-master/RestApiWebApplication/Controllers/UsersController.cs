﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RestApiWebApplication.Resources;
using RestApiWebApplication.Services;

namespace RestApiWebApplication.Controllers
{
    [ApiController]
    [Route("api/users")]
    [Authorize]
    public class UsersController : MyController<UserService>
    {
        public UsersController(UserService userService) : base(userService) { }

        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<UserResource>), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IEnumerable<UserResource> GetUsers()
        {
            return _service.GetUsers();
        }

        [HttpGet("{id}")]
        [ProducesResponseType(typeof(UserResource), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public async Task<IActionResult> GetUser(int id)
        {
            var user = await _service.GetUser(id);

            if (user is null)
            {
                return NotFound();
            }

            return Ok(user);
        }

        [HttpDelete("{id}")]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public async Task<IActionResult> DeleteUser(int id)
        {
            var deletedUser = await _service.DeleteUser(id);

            if (deletedUser is null)
            {
                return NotFound();
            }

            return Ok(deletedUser);
        }
    }
}
