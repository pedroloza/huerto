﻿using Microsoft.AspNetCore.Mvc;
using RestApiWebApplication.Models;
using RestApiWebApplication.Resources;
using RestApiWebApplication.Services;

namespace RestApiWebApplication.Controllers
{
    [ApiController]
    [Route("api/people")]
    public class PeopleController : MyController<PeopleService>
    {
        public PeopleController(PeopleService peopleService) : base(peopleService) { }

        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<PersonResource>), 200)]
        [ProducesResponseType(400)]
        public IEnumerable<PersonResource> GetPeople()
        {
            return _service.GetPeople();
        }

        [HttpGet("{id}")]
        [ProducesResponseType(typeof(PersonResource), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public async Task<IActionResult> GetPerson(int id)
        {
            var person = await _service.GetPerson(id);

            if (person is null)
            {
                return NotFound();
            }

            return Ok(person);
        }

        [HttpPut("{id}")]
        [ProducesResponseType(typeof(PersonResource), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public async Task<IActionResult> UpdatePerson(int id, Person person)
        {
            var personUpdated = await _service.UpdatePerson(id, person);

            if (personUpdated is null)
            {
                return NotFound();
            }

            return Ok(personUpdated);
        }

        [HttpDelete("{id}")]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public async Task<IActionResult> DeletePerson(int id)
        {
            var deletedPerson = await _service.DeletePerson(id);

            if (deletedPerson is null)
            {
                return NotFound();
            }

            return Ok(deletedPerson);
        }
    }
}
