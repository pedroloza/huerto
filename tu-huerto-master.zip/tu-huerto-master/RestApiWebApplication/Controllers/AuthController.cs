﻿using Microsoft.AspNetCore.Mvc;
using RestApiWebApplication.Resources;
using RestApiWebApplication.Services;

namespace RestApiWebApplication.Controllers
{
    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly UserService _userService = null!;

        public AuthController(UserService userService)
        {
            _userService = userService;
        }

        [HttpPost("register")]
        [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Register([FromBody] RegisterUserDTO body, CancellationToken cancellationToken)
        {
            try
            {
                var response = await _userService.Register(body, cancellationToken);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.InnerException });
            }
        }

        [HttpPost("login")]
        [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Login([FromBody] LoginDTO body, CancellationToken cancellationToken)
        {
            try
            {
                var response = await _userService.Login(body, cancellationToken);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.InnerException });
            }
        }
    }
}
