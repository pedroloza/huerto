using Microsoft.AspNetCore.Mvc;

namespace RestApiWebApplication.Controllers
{
  public class MyController<S> : ControllerBase
  {
    public readonly S _service;

    public MyController(S service)
    {
      _service = service;
    }
  }
}