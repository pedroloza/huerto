/**
 * Scripts
 */
const start = () => {
  "use strict"

  // Enable Bootstrap tooltips via data-attributes globally
  $('[data-toggle="tooltip"]').tooltip()

  // Enable Bootstrap popovers via data-attributes globally
  $('[data-toggle="popover"]').popover()

  $(".popover-dismiss").popover({
    trigger: "focus"
  })

  // Add active state to sidbar nav links
  var path = window.location.href // because the 'href' property of the DOM element is the absolute path
  $("#layoutSidenav_nav .sidenav a.nav-link").each(function () {
    if (this.href === path) {
      $(this).addClass("active")
    }
  })

  // Toggle the side navigation
  $("#sidebarToggle").on("click", function (e) {
    e.preventDefault()
    $("body").toggleClass("sidenav-toggled")
  })

  // Activate Feather icons
  feather.replace()

  // Activate Bootstrap scrollspy for the sticky nav component
  $("body").scrollspy({
    target: "#stickyNav",
    offset: 82
  })

  // Scrolls to an offset anchor when a sticky nav link is clicked
  $('.nav-sticky a.nav-link[href*="#"]:not([href="#"])').click(function () {
    if (
      location.pathname.replace(/^\//, "") == this.pathname.replace(/^\//, "") &&
      location.hostname == this.hostname
    ) {
      var target = $(this.hash)
      target = target.length ? target : $("[name=" + this.hash.slice(1) + "]")
      if (target.length) {
        $("html, body").animate(
          {
            scrollTop: target.offset().top - 81
          },
          200
        )
        return false
      }
    }
  })

  // Click to collapse responsive sidebar
  $("#layoutSidenav_content").click(function () {
    const BOOTSTRAP_LG_WIDTH = 992
    if (window.innerWidth >= 992) {
      return
    }
    if ($("body").hasClass("sidenav-toggled")) {
      $("body").toggleClass("sidenav-toggled")
    }
  })

  // Init sidebar
  let activatedPath = window.location.pathname.match(/([\w-]+\.html)/, "$1")

  if (activatedPath) {
    activatedPath = activatedPath[0]
  } else {
    activatedPath = "index.html"
  }

  let targetAnchor = $('[href="' + activatedPath + '"]')
  let collapseAncestors = targetAnchor.parents(".collapse")

  targetAnchor.addClass("active")

  collapseAncestors.each(function () {
    $(this).addClass("show")
    $('[data-target="#' + this.id + '"]').removeClass("collapsed")
  })
}
window.addEventListener("load", start)

/**
 * DataTables basic configuration
 */
function startDataTables () {
  console.log("DataTables executing...")
  // const dataTable = $("#dataTable")
  // console.log('dataTable :>> ', dataTable);
  if (!$("#dataTable").length) return
  $("#dataTable").DataTable()
  $("#dataTableActivity").DataTable({ order: [[0, "desc"]] })
  console.log('pass');
}
function onInitPage (param) {
  console.log('param :>> ', param);
  // window.addEventListener("scroll", startDataTables)
}

  $(document).ready(function () {
    $('#dataTable').DataTable()
    $('#dataTableActivity').DataTable({ order: [[0, "desc"]] })
    console.log('datatable called');
  })
// window.addEventListener("load", startDataTables)
// window.addEventListener("scroll", startDataTables)

/**
 * Chart.js basic configuration
 */
// Set new default font family and font color to mimic Bootstrap's default styling
;(Chart.defaults.global.defaultFontFamily = "Metropolis"),
  '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif'
Chart.defaults.global.defaultFontColor = "#858796"

const startChartPieGreens = () => {
  const ctx = document.getElementById("myPieChartGreens")
  if (!ctx) return
  new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: ["Direct", "Referral", "Social"],
      datasets: [
        {
          data: [55, 30, 15],
          backgroundColor: ["rgba(0, 97, 242, 1)", "rgba(0, 172, 105, 1)", "rgba(88, 0, 232, 1)"],
          hoverBackgroundColor: ["rgba(0, 97, 242, 0.9)", "rgba(0, 172, 105, 0.9)", "rgba(88, 0, 232, 0.9)"],
          hoverBorderColor: "rgba(234, 236, 244, 1)"
        }
      ]
    },
    options: {
      maintainAspectRatio: false,
      tooltips: {
        backgroundColor: "rgb(255,255,255)",
        bodyFontColor: "#858796",
        borderColor: "#dddfeb",
        borderWidth: 1,
        xPadding: 15,
        yPadding: 15,
        displayColors: false,
        caretPadding: 10
      },
      legend: {
        display: false
      },
      cutoutPercentage: 80
    }
  })
}
const startChartPieDemoLocation = () => {
  const ctx = document.getElementById("myPieChartUbication")
  if (!ctx) return
  new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: ["Direct", "Referral", "Social"],
      datasets: [
        {
          data: [55, 30, 15],
          backgroundColor: ["rgba(0, 97, 242, 1)", "rgba(0, 172, 105, 1)", "rgba(88, 0, 232, 1)"],
          hoverBackgroundColor: ["rgba(0, 97, 242, 0.9)", "rgba(0, 172, 105, 0.9)", "rgba(88, 0, 232, 0.9)"],
          hoverBorderColor: "rgba(234, 236, 244, 1)"
        }
      ]
    },
    options: {
      maintainAspectRatio: false,
      tooltips: {
        backgroundColor: "rgb(255,255,255)",
        bodyFontColor: "#858796",
        borderColor: "#dddfeb",
        borderWidth: 1,
        xPadding: 15,
        yPadding: 15,
        displayColors: false,
        caretPadding: 10
      },
      legend: {
        display: false
      },
      cutoutPercentage: 80
    }
  })
}
const startChartPieDemoVegetables = () => {
  const ctx = document.getElementById("myPieChartVegetables")
  if (!ctx) return
  new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: ["Direct", "Referral", "Social"],
      datasets: [
        {
          data: [55, 30, 15],
          backgroundColor: ["rgba(0, 97, 242, 1)", "rgba(0, 172, 105, 1)", "rgba(88, 0, 232, 1)"],
          hoverBackgroundColor: ["rgba(0, 97, 242, 0.9)", "rgba(0, 172, 105, 0.9)", "rgba(88, 0, 232, 0.9)"],
          hoverBorderColor: "rgba(234, 236, 244, 1)"
        }
      ]
    },
    options: {
      maintainAspectRatio: false,
      tooltips: {
        backgroundColor: "rgb(255,255,255)",
        bodyFontColor: "#858796",
        borderColor: "#dddfeb",
        borderWidth: 1,
        xPadding: 15,
        yPadding: 15,
        displayColors: false,
        caretPadding: 10
      },
      legend: {
        display: false
      },
      cutoutPercentage: 80
    }
  })
}
window.addEventListener("resize", startChartPieGreens)
window.addEventListener("scroll", startChartPieGreens)
window.addEventListener("resize", startChartPieDemoLocation)
window.addEventListener("scroll", startChartPieDemoLocation)
window.addEventListener("resize", startChartPieDemoVegetables)
window.addEventListener("scroll", startChartPieDemoVegetables)
