public class NavigationItem
{
  public string Name { get; set; } = "";
  public string Url { get; set; } = "";
}